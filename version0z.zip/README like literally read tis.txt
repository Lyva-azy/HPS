RIGHT.
to open the doo daad you press on v000z not v000z.pck

also this aint weird shit
i named it v000z cuz like

"version 0.0.0 Z"

yk   <-- (i wish i could add a skull emoji here)

if it doesnt run show me what pops up
if nothing pops up then uhhhhhhhhhhhh
i dont actually know, i guess vulkan aint even there then youll need an upgrade

if the game does run then YAYAYYAYAY  